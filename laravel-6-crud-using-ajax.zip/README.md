Step 1:
git clone https://github.com/siddharth018/laravel-6-crud-using-ajax
cd laravel-6-crud-using-ajax

Step 2: 
Configure database in .env file

DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=laravel_book
DB_USERNAME=root
DB_PASSWORD=root@123

Step 3:
php artisan migrate 

Step 4:
php artisan serve 

Step 5: 
http://127.0.0.1:8000/books



